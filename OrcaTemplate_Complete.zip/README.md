﻿# ðŸ‹ Orca Template - Package Complet

Bienvenue dans le **Orca Template Package**! Ce package contient tout ce dont vous avez besoin pour crÃ©er des scripts Roblox modernes avec une interface avancÃ©e.

## ðŸ“¦ Contenu du Package

- âœ… **Template Orca complet** (code source TypeScript)
- âœ… **Outils de build** (Rojo 7.6.1, Remodel 0.11.0)
- âœ… **Scripts automatisÃ©s** (build-all.ps1, QuickStart.bat)
- âœ… **Documentation complÃ¨te** (GUIDE_COMPLET_ORCA.md)
- âœ… **Exemples de code** et structure de projet

## ðŸš€ DÃ©marrage Rapide (30 secondes)

### MÃ©thode 1: Script automatique (Windows)
\\\ash
# Double-cliquer sur QuickStart.bat
# Ou exÃ©cuter dans PowerShell:
.\QuickStart.bat
\\\

### MÃ©thode 2: Commandes manuelles
\\\ash
# 1. Installer les dÃ©pendances
npm install

# 2. Compiler TypeScript â†’ Lua
npm run compile

# 3. Builder le modÃ¨le Roblox
.\rojo.exe build default.project.json --output Orca.rbxm

# 4. CrÃ©er le bundle final
.\remodel.exe run ci/bundle.lua public/orca-custom.lua custom verbose
\\\

### MÃ©thode 3: Script PowerShell avancÃ©
\\\powershell
# Build de dÃ©veloppement
.\build-all.ps1 -Mode dev

# Build de production minifiÃ©e
.\build-all.ps1 -Mode minify -Verbose
\\\

## ðŸ“ Structure du Projet

\\\
OrcaTemplate/
â”œâ”€â”€ ðŸ“‚ src/                    # Code source TypeScript
â”‚   â”œâ”€â”€ App.tsx               # Composant principal
â”‚   â”œâ”€â”€ components/           # Composants UI
â”‚   â”œâ”€â”€ views/                # Pages/Vues
â”‚   â”œâ”€â”€ store/                # State management (Rodux)
â”‚   â””â”€â”€ hooks/                # React hooks customs
â”‚
â”œâ”€â”€ ðŸ“‚ tools/                  # Outils de build
â”‚   â”œâ”€â”€ rojo.exe              # Synchronisation Roblox
â”‚   â””â”€â”€ remodel.exe           # Bundling Lua
â”‚
â”œâ”€â”€ ðŸ“‚ ci/                     # Scripts de build
â”‚   â”œâ”€â”€ bundle.lua            # Script de bundling
â”‚   â””â”€â”€ runtime.lua           # Runtime du bundle
â”‚
â”œâ”€â”€ ðŸ“‚ public/                 # Fichiers de sortie
â”‚   â””â”€â”€ orca-custom.lua       # Bundle final
â”‚
â”œâ”€â”€ ðŸ“„ build-all.ps1           # Script de build automatique
â”œâ”€â”€ ðŸ“„ QuickStart.bat          # DÃ©marrage rapide
â”œâ”€â”€ ðŸ“„ package.json            # DÃ©pendances npm
â”œâ”€â”€ ðŸ“„ tsconfig.json           # Config TypeScript
â””â”€â”€ ðŸ“„ GUIDE_COMPLET_ORCA.md   # Documentation complÃ¨te
\\\

## ðŸ’» PrÃ©requis

- **Node.js** v16+ ([tÃ©lÃ©charger](https://nodejs.org))
- **npm** (inclus avec Node.js)
- **Windows** (pour les .exe fournis)

> **Linux/Mac**: TÃ©lÃ©chargez les binaires Rojo/Remodel pour votre OS depuis GitHub.

## ðŸ“š Documentation

### Guide Complet
Consultez **GUIDE_COMPLET_ORCA.md** pour:
- Architecture dÃ©taillÃ©e
- Tutoriels pas Ã  pas
- Exemples de code
- Techniques avancÃ©es
- Optimisation et performance

### Ressources Officielles
- [roblox-ts Documentation](https://roblox-ts.com/)
- [Roact Guide](https://roblox.github.io/roact/)
- [Rodux Documentation](https://roblox.github.io/rodux/)
- [Rojo Documentation](https://rojo.space/)

## ðŸŽ¯ Workflow de DÃ©veloppement

### 1. DÃ©veloppement avec Hot Reload
\\\ash
# Terminal 1: Compiler en mode watch
npm run watch

# Terminal 2: Serveur Rojo
npm run serve

# Dans Roblox Studio:
# Plugins â†’ Rojo â†’ Connect to localhost:34872
\\\

### 2. Tester les Modifications
- Modifiez le code dans \src/\
- Sauvegardez le fichier
- Le changement apparaÃ®t instantanÃ©ment dans Studio

### 3. Build de Production
\\\ash
# Build complet optimisÃ©
.\build-all.ps1 -Mode prod

# Ou minifiÃ©
.\build-all.ps1 -Mode minify
\\\

## ðŸ”§ Personnalisation

### CrÃ©er un Nouveau Composant
\\\	ypescript
// src/components/MyButton.tsx
import Roact from "@rbxts/roact";
import { hooked, useState } from "@rbxts/roact-hooked";

export const MyButton = hooked<{ text: string }>((props) => {
    const [clicked, setClicked] = useState(false);
    
    return (
        <textbutton
            Text={props.text}
            Size={new UDim2(0, 200, 0, 50)}
            Event={{
                MouseButton1Click: () => setClicked(true)
            }}
        />
    );
});
\\\

### Modifier le ThÃ¨me
\\\	ypescript
// src/themes/my-theme.ts
export const myTheme = {
    background: Color3.fromRGB(20, 20, 20),
    foreground: Color3.fromRGB(30, 30, 30),
    accent: Color3.fromRGB(0, 120, 215),
    // ...
};
\\\

## ðŸ› Troubleshooting

### Erreur "npm not found"
- Installez Node.js depuis https://nodejs.org
- RedÃ©marrez votre terminal

### Erreur "rojo.exe not found"
- VÃ©rifiez que \ojo.exe\ est dans le dossier \	ools/\
- Ou tÃ©lÃ©chargez manuellement depuis GitHub

### Erreur de compilation TypeScript
\\\ash
# Nettoyer et recompiler
rm -rf out
npm run compile
\\\

### Bundle ne fonctionne pas dans Roblox
- VÃ©rifiez que votre executor supporte \loadstring\
- Testez avec la version debug: \public/*.debug.lua\

## ðŸŽ“ Prochaines Ã‰tapes

1. âœ… Lisez le **GUIDE_COMPLET_ORCA.md**
2. âœ… Explorez le code source dans \src/\
3. âœ… Testez le hot reload avec Rojo
4. âœ… CrÃ©ez votre premier composant
5. âœ… Buildez votre premier script

## ðŸ“ž Support

- **Discord roblox-ts**: https://discord.gg/f6Rn6RY
- **GitHub Orca**: https://github.com/richie0866/orca
- **Documentation**: Consultez GUIDE_COMPLET_ORCA.md

---

**Bon dÃ©veloppement! ðŸš€**

CrÃ©Ã© avec â¤ï¸ pour la communautÃ© Roblox
