# 🐋 Guide Complet : Créer une Interface Roblox Moderne comme Orca

## 📚 Table des Matières
1. [Introduction](#introduction)
2. [Architecture et Technologies](#architecture-et-technologies)
3. [Configuration de l'Environnement](#configuration-de-lenvironnement)
4. [Structure du Projet](#structure-du-projet)
5. [Concepts Clés](#concepts-clés)
6. [Développement Pas à Pas](#développement-pas-à-pas)
7. [Build et Déploiement](#build-et-déploiement)
8. [Techniques Avancées](#techniques-avancées)
9. [Optimisation et Performance](#optimisation-et-performance)
10. [Ressources](#ressources)

---

## 🎯 Introduction

**Orca** est un script hub Roblox moderne utilisant une architecture professionnelle basée sur:
- **TypeScript** → Lua compilation
- **Roact** (React pour Roblox)
- **Rodux** (Redux pour state management)
- **Animations Flipper** (moteur d'animation)

### Pourquoi cette architecture ?

✅ **Code typé** - Détection d'erreurs à la compilation  
✅ **Composants réutilisables** - Architecture modulaire  
✅ **State management centralisé** - Données prévisibles  
✅ **Hot reload** - Développement rapide avec Rojo  
✅ **Bundle optimisé** - Un seul fichier Lua final  

---

## 🏗️ Architecture et Technologies

### Stack Technique

```
┌─────────────────────────────────────────┐
│         TypeScript (.tsx)               │
│  Code source avec types et JSX          │
└─────────────┬───────────────────────────┘
              │ roblox-ts compile
              ▼
┌─────────────────────────────────────────┐
│          Lua Modules (.lua)             │
│  Code Lua avec système de modules       │
└─────────────┬───────────────────────────┘
              │ Rojo build
              ▼
┌─────────────────────────────────────────┐
│       Roblox Model (.rbxm)              │
│  Structure Roblox avec instances        │
└─────────────┬───────────────────────────┘
              │ Remodel bundle
              ▼
┌─────────────────────────────────────────┐
│      Single Lua File (.lua)             │
│  Script exécutable autonome             │
└─────────────────────────────────────────┘
```

### Technologies Utilisées

#### 1. **roblox-ts** (Compilateur TypeScript → Lua)
```bash
npm install -D roblox-ts
```
- Convertit TypeScript en Lua
- Support complet de TypeScript
- Transforme JSX en appels Roact
- Génère des modules compatibles Roblox

#### 2. **Roact** (Framework UI)
```typescript
import Roact from "@rbxts/roact";

const MyComponent = () => {
    return <frame Size={new UDim2(0, 200, 0, 100)} />;
};
```
- Équivalent React pour Roblox
- Composants déclaratifs
- Virtual DOM
- Lifecycle hooks

#### 3. **Rodux** (State Management)
```typescript
// Store Redux-like
const store = new Rodux.Store(reducer, initialState);

// Actions
store.dispatch({ type: "INCREMENT" });

// Selectors
const count = store.getState().count;
```
- Pattern Redux
- Store centralisé
- Actions immuables
- Middleware support

#### 4. **Roact Hooked** (React Hooks)
```typescript
import { hooked, useState, useEffect } from "@rbxts/roact-hooked";

const Counter = hooked(() => {
    const [count, setCount] = useState(0);
    
    useEffect(() => {
        print("Count changed:", count);
    }, [count]);
    
    return <textbutton 
        Text={`Count: ${count}`}
        Event={{ MouseButton1Click: () => setCount(count + 1) }}
    />;
});
```

#### 5. **Flipper** (Animations)
```typescript
import { SingleMotor, Spring } from "@rbxts/flipper";

const motor = new SingleMotor(0);
motor.setGoal(new Spring(1, { frequency: 2 }));

motor.onStep((value) => {
    frame.BackgroundTransparency = value;
});
```

#### 6. **Rojo** (Synchronisation Roblox)
- Convertit fichiers → instances Roblox
- Hot reload pendant développement
- Build de modèles .rbxm

#### 7. **Remodel** (Automation Lua)
- Scripting de manipulation de modèles
- Bundling en un seul fichier
- Minification optionnelle

---

## ⚙️ Configuration de l'Environnement

### Prérequis

1. **Node.js** (v16+)
   ```bash
   node --version  # v16.0.0+
   ```

2. **npm** (inclus avec Node.js)
   ```bash
   npm --version
   ```

3. **Rojo** (v7.6+)
   - Télécharger: https://github.com/rojo-rbx/rojo/releases
   - Placer `rojo.exe` dans le PATH ou le dossier projet

4. **Remodel** (v0.11+)
   - Télécharger: https://github.com/rojo-rbx/remodel/releases
   - Placer `remodel.exe` dans le PATH ou le dossier projet

### Installation du Template Orca

```bash
# Cloner le template
git clone https://github.com/richie0866/orca.git mon-projet

# Installer les dépendances npm
cd mon-projet
npm install

# Compiler TypeScript → Lua
npm run compile

# Builder le modèle Roblox
npm run build

# Créer le bundle final
npm run bundle
```

---

## 📁 Structure du Projet

```
mon-projet/
├── 📂 src/                      # Code source TypeScript
│   ├── App.tsx                  # Composant racine
│   ├── main.client.tsx          # Point d'entrée (LocalScript)
│   ├── constants.ts             # Constantes globales
│   │
│   ├── 📂 components/           # Composants UI réutilisables
│   │   ├── Card.tsx
│   │   ├── Button.tsx
│   │   ├── Acrylic/            # Effet Acrylic (Windows 11-like)
│   │   └── ...
│   │
│   ├── 📂 views/                # Pages/Vues principales
│   │   ├── Dashboard/
│   │   ├── Pages/
│   │   └── Navbar/
│   │
│   ├── 📂 store/                # State management Rodux
│   │   ├── store.ts            # Configuration du store
│   │   ├── actions/            # Actions Redux
│   │   ├── reducers/           # Reducers Redux
│   │   └── models/             # Types de state
│   │
│   ├── 📂 hooks/                # Custom React hooks
│   │   ├── use-theme.ts
│   │   ├── use-scale.ts
│   │   └── common/
│   │
│   ├── 📂 themes/               # Thèmes visuels
│   │   ├── dark-theme.ts
│   │   ├── light-theme.ts
│   │   └── theme.interface.ts
│   │
│   ├── 📂 jobs/                 # Scripts/actions Roblox
│   │   ├── character/          # Manipulation du personnage
│   │   ├── players/            # Actions sur les joueurs
│   │   └── ...
│   │
│   └── 📂 utils/                # Utilitaires
│       ├── color3.ts
│       ├── http.ts
│       └── ...
│
├── 📂 out/                      # Lua compilé (généré)
├── 📂 public/                   # Bundles finaux
│   ├── latest.lua              # Release stable
│   ├── snapshot.lua            # Version développement
│   └── *.debug.lua             # Versions avec debug
│
├── 📂 ci/                       # Scripts de build
│   ├── bundle.lua              # Script Remodel pour bundling
│   ├── runtime.lua             # Runtime du bundle
│   └── minify.js               # Minification
│
├── 📂 include/                  # Fichiers Lua statiques
│   ├── RuntimeLib.lua
│   └── Promise.lua
│
├── 📄 default.project.json      # Config Rojo (build)
├── 📄 place.project.json        # Config Rojo (serve)
├── 📄 tsconfig.json             # Config TypeScript
├── 📄 package.json              # Dépendances npm
└── 📄 README.md
```

---

## 💡 Concepts Clés

### 1. Composants Roact (TSX)

```typescript
// src/components/MyButton.tsx
import Roact from "@rbxts/roact";
import { hooked, useState } from "@rbxts/roact-hooked";

interface Props {
    text: string;
    onClick: () => void;
}

export const MyButton = hooked<Props>((props) => {
    const [hovered, setHovered] = useState(false);
    
    return (
        <textbutton
            Size={new UDim2(0, 200, 0, 50)}
            BackgroundColor3={hovered ? Color3.fromRGB(70, 70, 70) : Color3.fromRGB(50, 50, 50)}
            Text={props.text}
            TextColor3={Color3.fromRGB(255, 255, 255)}
            Font={Enum.Font.GothamBold}
            TextSize={16}
            Event={{
                MouseButton1Click: props.onClick,
                MouseEnter: () => setHovered(true),
                MouseLeave: () => setHovered(false),
            }}
        >
            <uicorner CornerRadius={new UDim(0, 8)} />
        </textbutton>
    );
});
```

### 2. State Management avec Rodux

```typescript
// src/store/models/counter.model.ts
export interface CounterState {
    count: number;
}

// src/store/actions/counter.action.ts
export const INCREMENT = "INCREMENT";
export const DECREMENT = "DECREMENT";

export const increment = () => ({ type: INCREMENT });
export const decrement = () => ({ type: DECREMENT });

// src/store/reducers/counter.reducer.ts
import { CounterState } from "../models/counter.model";
import { INCREMENT, DECREMENT } from "../actions/counter.action";

const initialState: CounterState = { count: 0 };

export const counterReducer = (state = initialState, action: any): CounterState => {
    switch (action.type) {
        case INCREMENT:
            return { count: state.count + 1 };
        case DECREMENT:
            return { count: state.count - 1 };
        default:
            return state;
    }
};

// src/store/store.ts
import Rodux from "@rbxts/rodux";
import { counterReducer } from "./reducers/counter.reducer";

export const configureStore = () => {
    return new Rodux.Store(counterReducer);
};
```

### 3. Utilisation du Store dans un Composant

```typescript
// src/views/Counter.tsx
import Roact from "@rbxts/roact";
import { hooked } from "@rbxts/roact-hooked";
import { useSelector, useDispatch } from "./hooks/rodux-hooks";
import { increment, decrement } from "./store/actions/counter.action";

export const Counter = hooked(() => {
    const count = useSelector((state) => state.count);
    const dispatch = useDispatch();
    
    return (
        <frame Size={UDim2.fromScale(1, 1)}>
            <textlabel
                Text={`Count: ${count}`}
                Size={new UDim2(0, 200, 0, 50)}
                TextSize={24}
            />
            <textbutton
                Text="+"
                Position={new UDim2(0, 0, 0, 60)}
                Size={new UDim2(0, 100, 0, 50)}
                Event={{ MouseButton1Click: () => dispatch(increment()) }}
            />
            <textbutton
                Text="-"
                Position={new UDim2(0, 110, 0, 60)}
                Size={new UDim2(0, 100, 0, 50)}
                Event={{ MouseButton1Click: () => dispatch(decrement()) }}
            />
        </frame>
    );
});
```

### 4. Animations avec Flipper

```typescript
// src/hooks/use-spring.ts
import { useState, useEffect } from "@rbxts/roact-hooked";
import { SingleMotor, Spring } from "@rbxts/flipper";

export const useSpring = (goal: number) => {
    const [value, setValue] = useState(0);
    const [motor] = useState(() => new SingleMotor(0));
    
    useEffect(() => {
        motor.onStep(setValue);
        motor.setGoal(new Spring(goal, { frequency: 4, dampingRatio: 1 }));
        
        return () => motor.destroy();
    }, [goal]);
    
    return value;
};

// Utilisation
const MyComponent = hooked(() => {
    const [visible, setVisible] = useState(false);
    const transparency = useSpring(visible ? 0 : 1);
    
    return (
        <frame BackgroundTransparency={transparency}>
            {/* ... */}
        </frame>
    );
});
```

### 5. Thèmes

```typescript
// src/themes/theme.interface.ts
export interface Theme {
    background: Color3;
    foreground: Color3;
    accent: Color3;
    text: Color3;
    border: Color3;
}

// src/themes/dark-theme.ts
export const darkTheme: Theme = {
    background: Color3.fromRGB(20, 20, 20),
    foreground: Color3.fromRGB(30, 30, 30),
    accent: Color3.fromRGB(0, 120, 215),
    text: Color3.fromRGB(255, 255, 255),
    border: Color3.fromRGB(60, 60, 60),
};

// src/hooks/use-theme.ts
import { useContext } from "@rbxts/roact-hooked";
import { ThemeContext } from "../context/theme-context";

export const useTheme = () => {
    return useContext(ThemeContext);
};
```

---

## 🚀 Développement Pas à Pas

### Étape 1: Créer un Nouveau Composant

```bash
# Créer le fichier
touch src/components/MyCard.tsx
```

```typescript
// src/components/MyCard.tsx
import Roact from "@rbxts/roact";
import { hooked } from "@rbxts/roact-hooked";
import { useTheme } from "../hooks/use-theme";

interface Props {
    title: string;
    children?: Roact.Element;
}

export const MyCard = hooked<Props>((props) => {
    const theme = useTheme();
    
    return (
        <frame
            Size={new UDim2(0, 300, 0, 200)}
            BackgroundColor3={theme.foreground}
            BorderSizePixel={0}
        >
            <uicorner CornerRadius={new UDim(0, 12)} />
            <uistroke 
                Color={theme.border} 
                Thickness={1}
                Transparency={0.5}
            />
            
            {/* Header */}
            <textlabel
                Size={new UDim2(1, -20, 0, 30)}
                Position={new UDim2(0, 10, 0, 10)}
                BackgroundTransparency={1}
                Text={props.title}
                TextColor3={theme.text}
                TextSize={18}
                Font={Enum.Font.GothamBold}
                TextXAlignment={Enum.TextXAlignment.Left}
            />
            
            {/* Content */}
            <frame
                Size={new UDim2(1, -20, 1, -50)}
                Position={new UDim2(0, 10, 0, 40)}
                BackgroundTransparency={1}
            >
                {props.children}
            </frame>
        </frame>
    );
});
```

### Étape 2: Intégrer dans une Vue

```typescript
// src/views/MyView.tsx
import Roact from "@rbxts/roact";
import { hooked } from "@rbxts/roact-hooked";
import { MyCard } from "../components/MyCard";

export const MyView = hooked(() => {
    return (
        <screengui ResetOnSpawn={false}>
            <MyCard title="Ma Première Card">
                <textlabel
                    Size={UDim2.fromScale(1, 1)}
                    BackgroundTransparency={1}
                    Text="Contenu de la card"
                    TextColor3={Color3.fromRGB(200, 200, 200)}
                />
            </MyCard>
        </screengui>
    );
});
```

### Étape 3: Compiler et Tester

```bash
# Terminal 1: Compiler en watch mode
npm run watch

# Terminal 2: Serveur Rojo (hot reload dans Studio)
npm run serve

# Ou builder directement
npm run compile
npm run build
npm run bundle
```

---

## 🔨 Build et Déploiement

### Scripts npm Disponibles

```json
{
  "scripts": {
    "compile": "rbxtsc --verbose --type=model",
    "watch": "rbxtsc -w",
    "build": "rojo build default.project.json --output Orca.rbxm",
    "serve": "rojo serve place.project.json",
    "bundle": "npm run build && remodel run ci/bundle.lua public/output.lua prod verbose",
    "bundle:min": "npm run build && remodel run ci/bundle.lua public/output.lua prod minify verbose"
  }
}
```

### Process Complet

```bash
# 1. Développement avec hot reload
npm run watch    # Terminal 1
npm run serve    # Terminal 2
# Ouvrir Roblox Studio → Plugin Rojo → Connect

# 2. Build de production
npm run compile  # TypeScript → Lua
npm run build    # Lua → Orca.rbxm
npm run bundle   # Orca.rbxm → single Lua file

# 3. Tester le bundle
# Copier public/output.lua dans un executor Roblox
loadstring(readfile("output.lua"))()
```

---

## 🎨 Techniques Avancées

### 1. Effet Acrylic (Windows 11-like)

```typescript
// Utilise ViewportFrame + ImageLabel pour l'effet de flou
// src/components/Acrylic/Acrylic.tsx
import Roact, { Binding } from "@rbxts/roact";
import { hooked, useEffect, useState } from "@rbxts/roact-hooked";

export const Acrylic = hooked(() => {
    const [blurSize, setBlurSize] = useState(24);
    
    return (
        <frame Size={UDim2.fromScale(1, 1)} BackgroundTransparency={1}>
            {/* Backdrop blur effect */}
            <frame
                BackgroundColor3={Color3.fromRGB(30, 30, 30)}
                BackgroundTransparency={0.3}
                Size={UDim2.fromScale(1, 1)}
            >
                <imageblur BlurSize={blurSize} />
            </frame>
        </frame>
    );
});
```

### 2. Parallax Scrolling

```typescript
// src/hooks/use-parallax-offset.ts
export const useParallaxOffset = (scrollPosition: number, speed: number) => {
    return scrollPosition * speed;
};

// Usage
const MyParallaxImage = hooked(() => {
    const [scrollY, setScrollY] = useState(0);
    const offset = useParallaxOffset(scrollY, 0.5);
    
    return (
        <imagelabel
            Position={new UDim2(0, 0, 0, offset)}
            // ...
        />
    );
});
```

### 3. Système de Navigation

```typescript
// src/store/models/navigation.model.ts
export enum Page {
    Home = "Home",
    Apps = "Apps",
    Scripts = "Scripts",
    Settings = "Settings",
}

export interface NavigationState {
    currentPage: Page;
}

// src/hooks/use-current-page.ts
export const useCurrentPage = () => {
    return useSelector((state) => state.navigation.currentPage);
};

// src/views/Dashboard/Dashboard.tsx
const Dashboard = hooked(() => {
    const currentPage = useCurrentPage();
    
    return (
        <frame>
            {currentPage === Page.Home && <HomePage />}
            {currentPage === Page.Apps && <AppsPage />}
            {currentPage === Page.Scripts && <ScriptsPage />}
            {currentPage === Page.Settings && <SettingsPage />}
        </frame>
    );
});
```

### 4. Gestion des Bindings (Reactive Values)

```typescript
import Roact, { Binding } from "@rbxts/roact";
import { useBinding } from "@rbxts/roact-hooked";

const MyComponent = hooked(() => {
    const [transparency, setTransparency] = useBinding(0);
    
    // Animate on mount
    useEffect(() => {
        const motor = new SingleMotor(0);
        motor.onStep(setTransparency);
        motor.setGoal(new Spring(1));
        
        return () => motor.destroy();
    }, []);
    
    return (
        <frame 
            BackgroundTransparency={transparency}
            // ...
        />
    );
});
```

---

## ⚡ Optimisation et Performance

### 1. Memoization

```typescript
import { useMemo } from "@rbxts/roact-hooked";

const ExpensiveComponent = hooked(() => {
    const expensiveValue = useMemo(() => {
        // Calcul coûteux
        return someHeavyComputation();
    }, [dependency]); // Ne recalcule que si dependency change
    
    return <textlabel Text={expensiveValue} />;
});
```

### 2. Lazy Loading

```typescript
// Charger les modules uniquement quand nécessaire
const loadScriptsPage = () => {
    return import("./views/Pages/ScriptsPage");
};
```

### 3. Debouncing

```typescript
const useDebounce = (value: string, delay: number) => {
    const [debouncedValue, setDebouncedValue] = useState(value);
    
    useEffect(() => {
        const timer = task.delay(delay, () => setDebouncedValue(value));
        return () => task.cancel(timer);
    }, [value]);
    
    return debouncedValue;
};
```

### 4. Bundle Minification

```bash
# Utiliser bundle:min pour minifier avec luamin
npm run bundle:min
```

---

## 📚 Ressources

### Documentation Officielle

- **roblox-ts**: https://roblox-ts.com/
- **Roact**: https://roblox.github.io/roact/
- **Rodux**: https://roblox.github.io/rodux/
- **Rojo**: https://rojo.space/
- **Flipper**: https://github.com/Reselim/flipper

### Exemples et Templates

- **Orca (source)**: https://github.com/richie0866/orca
- **Roact DevHub**: https://devforum.roblox.com/tag/roact

### Communauté

- **roblox-ts Discord**: https://discord.gg/f6Rn6RY
- **Rojo Discord**: https://discord.gg/wH5ncNS

---

## 🎓 Checklist de Développement

### Setup Initial
- [ ] Node.js installé
- [ ] Rojo téléchargé
- [ ] Remodel téléchargé
- [ ] Template cloné
- [ ] `npm install` exécuté

### Développement
- [ ] Composants créés dans `src/components/`
- [ ] Vues créées dans `src/views/`
- [ ] Store configuré dans `src/store/`
- [ ] Hooks customs dans `src/hooks/`
- [ ] Thèmes définis dans `src/themes/`

### Build
- [ ] `npm run compile` sans erreurs
- [ ] `npm run build` génère Orca.rbxm
- [ ] `npm run bundle` crée le fichier final
- [ ] Test dans un executor Roblox

### Déploiement
- [ ] Bundle minifié (`bundle:min`)
- [ ] Testé sur plusieurs jeux
- [ ] Upload sur GitHub/Pastebin
- [ ] Documentation utilisateur créée

---

## 🔧 Troubleshooting

### Erreur "Module not found"
```bash
# Réinstaller les dépendances
rm -rf node_modules
npm install
```

### Erreur de compilation TypeScript
```bash
# Vérifier tsconfig.json
# Nettoyer le cache
rm -rf out
npm run compile
```

### Rojo ne se connecte pas
```bash
# Vérifier le port (default: 34872)
# Redémarrer Roblox Studio
# Relancer rojo serve
```

### Bundle ne fonctionne pas
```bash
# Vérifier que Orca.rbxm existe
# Vérifier ci/bundle.lua et ci/runtime.lua
# Tester avec la version debug
```

---

## 📝 Notes Finales

Cette architecture permet de créer des interfaces Roblox **professionnelles**, **maintenables** et **performantes**. 

**Avantages clés:**
- Code organisé et typé
- Hot reload pendant le développement
- Animations fluides
- State management prévisible
- Bundle optimisé pour la production

**Points d'attention:**
- Courbe d'apprentissage (TypeScript + React concepts)
- Temps de compilation
- Taille du bundle final (optimisable avec minification)

Bon développement! 🚀
