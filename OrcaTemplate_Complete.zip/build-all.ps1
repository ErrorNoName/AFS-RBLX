# ============================================
# 🐋 Orca Build Script - Build Automatique
# ============================================
# Ce script automatise le build complet d'un projet Orca
# TypeScript → Lua → RBXM → Bundle

param(
    [string]$Mode = "dev",  # dev, prod, minify
    [switch]$SkipCompile,   # Skip npm compilation
    [switch]$SkipBundle,    # Skip bundling step
    [switch]$Verbose        # Verbose output
)

# Couleurs pour output
function Write-Success { param($msg) Write-Host "✅ $msg" -ForegroundColor Green }
function Write-Error { param($msg) Write-Host "❌ $msg" -ForegroundColor Red }
function Write-Info { param($msg) Write-Host "ℹ️  $msg" -ForegroundColor Cyan }
function Write-Step { param($msg) Write-Host "`n🔧 $msg..." -ForegroundColor Yellow }

# Configuration
$ProjectRoot = $PSScriptRoot
$RojoExe = Join-Path $ProjectRoot "rojo.exe"
$RemodelExe = Join-Path $ProjectRoot "remodel.exe"
$OutDir = Join-Path $ProjectRoot "out"
$PublicDir = Join-Path $ProjectRoot "public"
$ModelFile = Join-Path $ProjectRoot "Orca.rbxm"

# Timestamp pour les fichiers
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"

# Déterminer le fichier de sortie selon le mode
switch ($Mode) {
    "dev" {
        $OutputFile = Join-Path $PublicDir "orca-dev.lua"
        $BundleMode = "custom"
    }
    "prod" {
        $OutputFile = Join-Path $PublicDir "orca-prod.lua"
        $BundleMode = "prod"
    }
    "minify" {
        $OutputFile = Join-Path $PublicDir "orca-min.lua"
        $BundleMode = "prod"
        $MinifyFlag = "minify"
    }
    default {
        $OutputFile = Join-Path $PublicDir "orca-build-$Timestamp.lua"
        $BundleMode = "custom"
    }
}

# Créer le dossier public si nécessaire
if (-not (Test-Path $PublicDir)) {
    New-Item -ItemType Directory -Path $PublicDir | Out-Null
}

Write-Host @"

==========================================
   ORCA BUILD SCRIPT v1.0
   Mode: $Mode                       
   Output: $(Split-Path $OutputFile -Leaf)
==========================================

"@ -ForegroundColor Magenta

# ============================================
# Étape 1: Vérification des outils
# ============================================
Write-Step "Vérification des outils requis"

# Vérifier Node.js
try {
    $NodeVersion = node --version 2>$null
    Write-Success "Node.js trouvé: $NodeVersion"
} catch {
    Write-Error "Node.js non trouvé! Installez Node.js depuis https://nodejs.org"
    exit 1
}

# Vérifier npm
try {
    $NpmVersion = npm --version 2>$null
    Write-Success "npm trouvé: v$NpmVersion"
} catch {
    Write-Error "npm non trouvé!"
    exit 1
}

# Vérifier Rojo
if (Test-Path $RojoExe) {
    Write-Success "Rojo trouvé: $RojoExe"
} else {
    Write-Error "Rojo non trouvé! Téléchargez-le depuis https://github.com/rojo-rbx/rojo/releases"
    Write-Info "Placez rojo.exe dans le dossier du projet"
    exit 1
}

# Vérifier Remodel
if (Test-Path $RemodelExe) {
    Write-Success "Remodel trouvé: $RemodelExe"
} else {
    Write-Error "Remodel non trouvé! Téléchargez-le depuis https://github.com/rojo-rbx/remodel/releases"
    Write-Info "Placez remodel.exe dans le dossier du projet"
    exit 1
}

# Vérifier node_modules
if (-not (Test-Path "node_modules")) {
    Write-Info "node_modules non trouvé, installation des dépendances..."
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Échec de l'installation des dépendances npm"
        exit 1
    }
    Write-Success "Dépendances installées"
}

# ============================================
# Étape 2: Compilation TypeScript → Lua
# ============================================
if (-not $SkipCompile) {
    Write-Step "Compilation TypeScript → Lua"
    
    # Nettoyer le dossier out
    if (Test-Path $OutDir) {
        Write-Info "Nettoyage du dossier out/..."
        Remove-Item -Recurse -Force $OutDir
    }
    
    # Compiler avec roblox-ts
    if ($Verbose) {
        npm run compile -- --verbose
    } else {
        npm run compile
    }
    
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Échec de la compilation TypeScript"
        exit 1
    }
    
    # Compter les fichiers générés
    $LuaFiles = (Get-ChildItem -Recurse -Filter "*.lua" $OutDir).Count
    Write-Success "Compilation réussie! ($LuaFiles fichiers Lua générés)"
} else {
    Write-Info "Compilation ignorée (--SkipCompile)"
}

# ============================================
# Étape 3: Build Rojo (Lua → RBXM)
# ============================================
Write-Step "Build du modèle Roblox avec Rojo"

# Supprimer l'ancien modèle
if (Test-Path $ModelFile) {
    Remove-Item $ModelFile
}

# Builder avec Rojo
if ($Verbose) {
    & $RojoExe build default.project.json --output $ModelFile
} else {
    & $RojoExe build default.project.json --output $ModelFile 2>&1 | Out-Null
}

if ($LASTEXITCODE -ne 0) {
    Write-Error "Échec du build Rojo"
    exit 1
}

if (Test-Path $ModelFile) {
    $ModelSize = [math]::Round((Get-Item $ModelFile).Length / 1KB, 2)
    Write-Success "Modèle Roblox créé: Orca.rbxm ($ModelSize KB)"
} else {
    Write-Error "Fichier Orca.rbxm non généré"
    exit 1
}

# ============================================
# Étape 4: Bundling avec Remodel
# ============================================
if (-not $SkipBundle) {
    Write-Step "Création du bundle Lua final"
    
    # Construire la commande Remodel
    $RemodelArgs = @("run", "ci/bundle.lua", $OutputFile, $BundleMode)
    
    if ($MinifyFlag) {
        $RemodelArgs += $MinifyFlag
    }
    
    if ($Verbose) {
        $RemodelArgs += "verbose"
    }
    
    # Exécuter Remodel
    & $RemodelExe $RemodelArgs
    
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Échec du bundling Remodel"
        exit 1
    }
    
    if (Test-Path $OutputFile) {
        $BundleSize = [math]::Round((Get-Item $OutputFile).Length / 1KB, 2)
        $Lines = (Get-Content $OutputFile).Count
        Write-Success "Bundle créé: $(Split-Path $OutputFile -Leaf) ($BundleSize KB, $Lines lignes)"
    } else {
        Write-Error "Fichier bundle non généré"
        exit 1
    }
} else {
    Write-Info "Bundling ignoré (--SkipBundle)"
}

# ============================================
# Étape 5: Résumé et fichiers générés
# ============================================
Write-Host "`n========================================" -ForegroundColor Green
Write-Host "   BUILD TERMINE AVEC SUCCES!          " -ForegroundColor Green
Write-Host "========================================`n" -ForegroundColor Green

Write-Info "Fichiers generes:"
Write-Host "   [RBXM] Modele Roblox: " -NoNewline; Write-Host "Orca.rbxm" -ForegroundColor Cyan
Write-Host "   [LUA]  Bundle Lua:    " -NoNewline; Write-Host "$(Split-Path $OutputFile -Leaf)" -ForegroundColor Cyan

Write-Host "`nPour tester le script dans Roblox:" -ForegroundColor Yellow
Write-Host "   loadstring(readfile(`"$($OutputFile)`"))())" -ForegroundColor Gray

Write-Host "`nStatistiques du build:" -ForegroundColor Yellow
if (Test-Path $OutDir) {
    $ModulesCount = (Get-ChildItem -Recurse -Filter "*.lua" $OutDir).Count
    Write-Host "   - Modules Lua compilés: $ModulesCount" -ForegroundColor Gray
}
if (Test-Path $ModelFile) {
    $ModelSize = [math]::Round((Get-Item $ModelFile).Length / 1KB, 2)
    Write-Host "   - Taille du modèle RBXM: $ModelSize KB" -ForegroundColor Gray
}
if (Test-Path $OutputFile) {
    $BundleSize = [math]::Round((Get-Item $OutputFile).Length / 1KB, 2)
    $BundleLines = (Get-Content $OutputFile).Count
    Write-Host "   - Taille du bundle: $BundleSize KB" -ForegroundColor Gray
    Write-Host "   - Lignes de code: $BundleLines" -ForegroundColor Gray
}

# ============================================
# Options supplémentaires
# ============================================
Write-Host "`nAutres modes disponibles:" -ForegroundColor Cyan
Write-Host "   .\build-all.ps1 -Mode dev       # Build developpement" -ForegroundColor Gray
Write-Host "   .\build-all.ps1 -Mode prod      # Build production" -ForegroundColor Gray
Write-Host "   .\build-all.ps1 -Mode minify    # Build minifie" -ForegroundColor Gray
Write-Host "   .\build-all.ps1 -Verbose        # Output detaille" -ForegroundColor Gray
Write-Host "   .\build-all.ps1 -SkipCompile    # Skip compilation TS" -ForegroundColor Gray

Write-Host "`nBuild termine en " -NoNewline -ForegroundColor Green
Write-Host (Get-Date) -ForegroundColor Gray
