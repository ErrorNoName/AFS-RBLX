export declare function EnableFreecam(): void;

export declare function DisableFreecam(): void;
