﻿import Roact from "@rbxts/roact";
import { hooked, useState } from "@rbxts/roact-hooked";

/**
 * Exemple de composant simple avec state et Ã©vÃ©nements
 */
export const ExampleCounter = hooked(() => {
    const [count, setCount] = useState(0);
    const [hovered, setHovered] = useState(false);
    
    return (
        <frame
            Size={new UDim2(0, 300, 0, 200)}
            Position={UDim2.fromScale(0.5, 0.5)}
            AnchorPoint={new Vector2(0.5, 0.5)}
            BackgroundColor3={Color3.fromRGB(30, 30, 30)}
            BorderSizePixel={0}
        >
            <uicorner CornerRadius={new UDim(0, 12)} />
            
            {/* Titre */}
            <textlabel
                Size={new UDim2(1, 0, 0, 50)}
                BackgroundTransparency={1}
                Text="Counter Example"
                TextColor3={Color3.fromRGB(255, 255, 255)}
                TextSize={24}
                Font={Enum.Font.GothamBold}
            />
            
            {/* Compteur */}
            <textlabel
                Size={new UDim2(1, 0, 0, 60)}
                Position={new UDim2(0, 0, 0, 60)}
                BackgroundTransparency={1}
                Text={\Count: \\}
                TextColor3={Color3.fromRGB(0, 200, 255)}
                TextSize={32}
                Font={Enum.Font.GothamBold}
            />
            
            {/* Bouton Increment */}
            <textbutton
                Size={new UDim2(0, 120, 0, 40)}
                Position={new UDim2(0.5, -65, 1, -50)}
                AnchorPoint={new Vector2(0, 0)}
                BackgroundColor3={hovered ? Color3.fromRGB(0, 150, 215) : Color3.fromRGB(0, 120, 215)}
                Text="+"
                TextColor3={Color3.fromRGB(255, 255, 255)}
                TextSize={24}
                Font={Enum.Font.GothamBold}
                Event={{
                    MouseButton1Click: () => setCount(count + 1),
                    MouseEnter: () => setHovered(true),
                    MouseLeave: () => setHovered(false),
                }}
            >
                <uicorner CornerRadius={new UDim(0, 8)} />
            </textbutton>
            
            {/* Bouton Decrement */}
            <textbutton
                Size={new UDim2(0, 120, 0, 40)}
                Position={new UDim2(0.5, 65, 1, -50)}
                AnchorPoint={new Vector2(1, 0)}
                BackgroundColor3={Color3.fromRGB(215, 60, 0)}
                Text="-"
                TextColor3={Color3.fromRGB(255, 255, 255)}
                TextSize={24}
                Font={Enum.Font.GothamBold}
                Event={{
                    MouseButton1Click: () => setCount(count - 1),
                }}
            >
                <uicorner CornerRadius={new UDim(0, 8)} />
            </textbutton>
        </frame>
    );
});
